/**
 */
package tagml.tests;

import tagml.FolderContent;

/**
 * <!-- begin-user-doc -->
 * A test case for the model object '<em><b>Folder Content</b></em>'.
 * <!-- end-user-doc -->
 * @generated
 */
public abstract class FolderContentTest extends ElementTest {

	/**
	 * Constructs a new Folder Content test case with the given name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public FolderContentTest(String name) {
		super(name);
	}

	/**
	 * Returns the fixture for this Folder Content test case.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected FolderContent getFixture() {
		return (FolderContent)fixture;
	}

} //FolderContentTest
