/**
 */
package tagml;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Attribute</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link tagml.Attribute#getTag <em>Tag</em>}</li>
 *   <li>{@link tagml.Attribute#getValue <em>Value</em>}</li>
 * </ul>
 *
 * @see tagml.TagmlPackage#getAttribute()
 * @model
 * @generated
 */
public interface Attribute extends Element {
	/**
	 * Returns the value of the '<em><b>Tag</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link tagml.Tag#getAttribute <em>Attribute</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Tag</em>' container reference.
	 * @see #setTag(Tag)
	 * @see tagml.TagmlPackage#getAttribute_Tag()
	 * @see tagml.Tag#getAttribute
	 * @model opposite="attribute" required="true" transient="false"
	 * @generated
	 */
	Tag getTag();

	/**
	 * Sets the value of the '{@link tagml.Attribute#getTag <em>Tag</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Tag</em>' container reference.
	 * @see #getTag()
	 * @generated
	 */
	void setTag(Tag value);

	/**
	 * Returns the value of the '<em><b>Value</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Value</em>' attribute.
	 * @see #setValue(String)
	 * @see tagml.TagmlPackage#getAttribute_Value()
	 * @model
	 * @generated
	 */
	String getValue();

	/**
	 * Sets the value of the '{@link tagml.Attribute#getValue <em>Value</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Value</em>' attribute.
	 * @see #getValue()
	 * @generated
	 */
	void setValue(String value);

} // Attribute
