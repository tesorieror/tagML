/**
 */
package tagml.impl;

import java.util.Collection;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.common.util.EList;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EObjectContainmentWithInverseEList;
import org.eclipse.emf.ecore.util.EcoreUtil;
import org.eclipse.emf.ecore.util.InternalEList;

import tagml.Attribute;
import tagml.Document;
import tagml.Tag;
import tagml.TagContent;
import tagml.TagmlPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Tag</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link tagml.impl.TagImpl#getParent <em>Parent</em>}</li>
 *   <li>{@link tagml.impl.TagImpl#getDocument <em>Document</em>}</li>
 *   <li>{@link tagml.impl.TagImpl#getAttribute <em>Attribute</em>}</li>
 *   <li>{@link tagml.impl.TagImpl#getContent <em>Content</em>}</li>
 * </ul>
 *
 * @generated
 */
public class TagImpl extends ElementImpl implements Tag {
	/**
	 * The cached value of the '{@link #getAttribute() <em>Attribute</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getAttribute()
	 * @generated
	 * @ordered
	 */
	protected EList<Attribute> attribute;

	/**
	 * The cached value of the '{@link #getContent() <em>Content</em>}' containment reference list.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see #getContent()
	 * @generated
	 * @ordered
	 */
	protected EList<TagContent> content;

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected TagImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return TagmlPackage.Literals.TAG;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Tag getParent() {
		if (eContainerFeatureID() != TagmlPackage.TAG__PARENT) return null;
		return (Tag)eInternalContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetParent(Tag newParent, NotificationChain msgs) {
		msgs = eBasicSetContainer((InternalEObject)newParent, TagmlPackage.TAG__PARENT, msgs);
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setParent(Tag newParent) {
		if (newParent != eInternalContainer() || (eContainerFeatureID() != TagmlPackage.TAG__PARENT && newParent != null)) {
			if (EcoreUtil.isAncestor(this, newParent))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newParent != null)
				msgs = ((InternalEObject)newParent).eInverseAdd(this, TagmlPackage.TAG__CONTENT, Tag.class, msgs);
			msgs = basicSetParent(newParent, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, TagmlPackage.TAG__PARENT, newParent, newParent));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<Attribute> getAttribute() {
		if (attribute == null) {
			attribute = new EObjectContainmentWithInverseEList<Attribute>(Attribute.class, this, TagmlPackage.TAG__ATTRIBUTE, TagmlPackage.ATTRIBUTE__TAG);
		}
		return attribute;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public EList<TagContent> getContent() {
		if (content == null) {
			content = new EObjectContainmentWithInverseEList<TagContent>(TagContent.class, this, TagmlPackage.TAG__CONTENT, TagmlPackage.TAG_CONTENT__PARENT);
		}
		return content;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Document getDocument() {
		if (eContainerFeatureID() != TagmlPackage.TAG__DOCUMENT) return null;
		return (Document)eInternalContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetDocument(Document newDocument, NotificationChain msgs) {
		msgs = eBasicSetContainer((InternalEObject)newDocument, TagmlPackage.TAG__DOCUMENT, msgs);
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setDocument(Document newDocument) {
		if (newDocument != eInternalContainer() || (eContainerFeatureID() != TagmlPackage.TAG__DOCUMENT && newDocument != null)) {
			if (EcoreUtil.isAncestor(this, newDocument))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newDocument != null)
				msgs = ((InternalEObject)newDocument).eInverseAdd(this, TagmlPackage.DOCUMENT__ROOT, Document.class, msgs);
			msgs = basicSetDocument(newDocument, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, TagmlPackage.TAG__DOCUMENT, newDocument, newDocument));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case TagmlPackage.TAG__PARENT:
				if (eInternalContainer() != null)
					msgs = eBasicRemoveFromContainer(msgs);
				return basicSetParent((Tag)otherEnd, msgs);
			case TagmlPackage.TAG__DOCUMENT:
				if (eInternalContainer() != null)
					msgs = eBasicRemoveFromContainer(msgs);
				return basicSetDocument((Document)otherEnd, msgs);
			case TagmlPackage.TAG__ATTRIBUTE:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getAttribute()).basicAdd(otherEnd, msgs);
			case TagmlPackage.TAG__CONTENT:
				return ((InternalEList<InternalEObject>)(InternalEList<?>)getContent()).basicAdd(otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case TagmlPackage.TAG__PARENT:
				return basicSetParent(null, msgs);
			case TagmlPackage.TAG__DOCUMENT:
				return basicSetDocument(null, msgs);
			case TagmlPackage.TAG__ATTRIBUTE:
				return ((InternalEList<?>)getAttribute()).basicRemove(otherEnd, msgs);
			case TagmlPackage.TAG__CONTENT:
				return ((InternalEList<?>)getContent()).basicRemove(otherEnd, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eBasicRemoveFromContainerFeature(NotificationChain msgs) {
		switch (eContainerFeatureID()) {
			case TagmlPackage.TAG__PARENT:
				return eInternalContainer().eInverseRemove(this, TagmlPackage.TAG__CONTENT, Tag.class, msgs);
			case TagmlPackage.TAG__DOCUMENT:
				return eInternalContainer().eInverseRemove(this, TagmlPackage.DOCUMENT__ROOT, Document.class, msgs);
		}
		return super.eBasicRemoveFromContainerFeature(msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case TagmlPackage.TAG__PARENT:
				return getParent();
			case TagmlPackage.TAG__DOCUMENT:
				return getDocument();
			case TagmlPackage.TAG__ATTRIBUTE:
				return getAttribute();
			case TagmlPackage.TAG__CONTENT:
				return getContent();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@SuppressWarnings("unchecked")
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case TagmlPackage.TAG__PARENT:
				setParent((Tag)newValue);
				return;
			case TagmlPackage.TAG__DOCUMENT:
				setDocument((Document)newValue);
				return;
			case TagmlPackage.TAG__ATTRIBUTE:
				getAttribute().clear();
				getAttribute().addAll((Collection<? extends Attribute>)newValue);
				return;
			case TagmlPackage.TAG__CONTENT:
				getContent().clear();
				getContent().addAll((Collection<? extends TagContent>)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case TagmlPackage.TAG__PARENT:
				setParent((Tag)null);
				return;
			case TagmlPackage.TAG__DOCUMENT:
				setDocument((Document)null);
				return;
			case TagmlPackage.TAG__ATTRIBUTE:
				getAttribute().clear();
				return;
			case TagmlPackage.TAG__CONTENT:
				getContent().clear();
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case TagmlPackage.TAG__PARENT:
				return getParent() != null;
			case TagmlPackage.TAG__DOCUMENT:
				return getDocument() != null;
			case TagmlPackage.TAG__ATTRIBUTE:
				return attribute != null && !attribute.isEmpty();
			case TagmlPackage.TAG__CONTENT:
				return content != null && !content.isEmpty();
		}
		return super.eIsSet(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eBaseStructuralFeatureID(int derivedFeatureID, Class<?> baseClass) {
		if (baseClass == TagContent.class) {
			switch (derivedFeatureID) {
				case TagmlPackage.TAG__PARENT: return TagmlPackage.TAG_CONTENT__PARENT;
				case TagmlPackage.TAG__DOCUMENT: return TagmlPackage.TAG_CONTENT__DOCUMENT;
				default: return -1;
			}
		}
		return super.eBaseStructuralFeatureID(derivedFeatureID, baseClass);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public int eDerivedStructuralFeatureID(int baseFeatureID, Class<?> baseClass) {
		if (baseClass == TagContent.class) {
			switch (baseFeatureID) {
				case TagmlPackage.TAG_CONTENT__PARENT: return TagmlPackage.TAG__PARENT;
				case TagmlPackage.TAG_CONTENT__DOCUMENT: return TagmlPackage.TAG__DOCUMENT;
				default: return -1;
			}
		}
		return super.eDerivedStructuralFeatureID(baseFeatureID, baseClass);
	}

} //TagImpl
