/**
 */
package tagml.impl;

import org.eclipse.emf.common.notify.Notification;
import org.eclipse.emf.common.notify.NotificationChain;

import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.InternalEObject;

import org.eclipse.emf.ecore.impl.ENotificationImpl;

import org.eclipse.emf.ecore.util.EcoreUtil;

import tagml.Archive;
import tagml.Folder;
import tagml.FolderContent;
import tagml.TagmlPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Folder Content</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * The following features are implemented:
 * </p>
 * <ul>
 *   <li>{@link tagml.impl.FolderContentImpl#getParent <em>Parent</em>}</li>
 *   <li>{@link tagml.impl.FolderContentImpl#getArchive <em>Archive</em>}</li>
 * </ul>
 *
 * @generated
 */
public abstract class FolderContentImpl extends ElementImpl implements FolderContent {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected FolderContentImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return TagmlPackage.Literals.FOLDER_CONTENT;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Folder getParent() {
		if (eContainerFeatureID() != TagmlPackage.FOLDER_CONTENT__PARENT) return null;
		return (Folder)eInternalContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetParent(Folder newParent, NotificationChain msgs) {
		msgs = eBasicSetContainer((InternalEObject)newParent, TagmlPackage.FOLDER_CONTENT__PARENT, msgs);
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setParent(Folder newParent) {
		if (newParent != eInternalContainer() || (eContainerFeatureID() != TagmlPackage.FOLDER_CONTENT__PARENT && newParent != null)) {
			if (EcoreUtil.isAncestor(this, newParent))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newParent != null)
				msgs = ((InternalEObject)newParent).eInverseAdd(this, TagmlPackage.FOLDER__CONTENTS, Folder.class, msgs);
			msgs = basicSetParent(newParent, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, TagmlPackage.FOLDER_CONTENT__PARENT, newParent, newParent));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public Archive getArchive() {
		if (eContainerFeatureID() != TagmlPackage.FOLDER_CONTENT__ARCHIVE) return null;
		return (Archive)eInternalContainer();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public NotificationChain basicSetArchive(Archive newArchive, NotificationChain msgs) {
		msgs = eBasicSetContainer((InternalEObject)newArchive, TagmlPackage.FOLDER_CONTENT__ARCHIVE, msgs);
		return msgs;
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	public void setArchive(Archive newArchive) {
		if (newArchive != eInternalContainer() || (eContainerFeatureID() != TagmlPackage.FOLDER_CONTENT__ARCHIVE && newArchive != null)) {
			if (EcoreUtil.isAncestor(this, newArchive))
				throw new IllegalArgumentException("Recursive containment not allowed for " + toString());
			NotificationChain msgs = null;
			if (eInternalContainer() != null)
				msgs = eBasicRemoveFromContainer(msgs);
			if (newArchive != null)
				msgs = ((InternalEObject)newArchive).eInverseAdd(this, TagmlPackage.ARCHIVE__CONTENTS, Archive.class, msgs);
			msgs = basicSetArchive(newArchive, msgs);
			if (msgs != null) msgs.dispatch();
		}
		else if (eNotificationRequired())
			eNotify(new ENotificationImpl(this, Notification.SET, TagmlPackage.FOLDER_CONTENT__ARCHIVE, newArchive, newArchive));
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseAdd(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case TagmlPackage.FOLDER_CONTENT__PARENT:
				if (eInternalContainer() != null)
					msgs = eBasicRemoveFromContainer(msgs);
				return basicSetParent((Folder)otherEnd, msgs);
			case TagmlPackage.FOLDER_CONTENT__ARCHIVE:
				if (eInternalContainer() != null)
					msgs = eBasicRemoveFromContainer(msgs);
				return basicSetArchive((Archive)otherEnd, msgs);
		}
		return super.eInverseAdd(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eInverseRemove(InternalEObject otherEnd, int featureID, NotificationChain msgs) {
		switch (featureID) {
			case TagmlPackage.FOLDER_CONTENT__PARENT:
				return basicSetParent(null, msgs);
			case TagmlPackage.FOLDER_CONTENT__ARCHIVE:
				return basicSetArchive(null, msgs);
		}
		return super.eInverseRemove(otherEnd, featureID, msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public NotificationChain eBasicRemoveFromContainerFeature(NotificationChain msgs) {
		switch (eContainerFeatureID()) {
			case TagmlPackage.FOLDER_CONTENT__PARENT:
				return eInternalContainer().eInverseRemove(this, TagmlPackage.FOLDER__CONTENTS, Folder.class, msgs);
			case TagmlPackage.FOLDER_CONTENT__ARCHIVE:
				return eInternalContainer().eInverseRemove(this, TagmlPackage.ARCHIVE__CONTENTS, Archive.class, msgs);
		}
		return super.eBasicRemoveFromContainerFeature(msgs);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public Object eGet(int featureID, boolean resolve, boolean coreType) {
		switch (featureID) {
			case TagmlPackage.FOLDER_CONTENT__PARENT:
				return getParent();
			case TagmlPackage.FOLDER_CONTENT__ARCHIVE:
				return getArchive();
		}
		return super.eGet(featureID, resolve, coreType);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eSet(int featureID, Object newValue) {
		switch (featureID) {
			case TagmlPackage.FOLDER_CONTENT__PARENT:
				setParent((Folder)newValue);
				return;
			case TagmlPackage.FOLDER_CONTENT__ARCHIVE:
				setArchive((Archive)newValue);
				return;
		}
		super.eSet(featureID, newValue);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public void eUnset(int featureID) {
		switch (featureID) {
			case TagmlPackage.FOLDER_CONTENT__PARENT:
				setParent((Folder)null);
				return;
			case TagmlPackage.FOLDER_CONTENT__ARCHIVE:
				setArchive((Archive)null);
				return;
		}
		super.eUnset(featureID);
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	public boolean eIsSet(int featureID) {
		switch (featureID) {
			case TagmlPackage.FOLDER_CONTENT__PARENT:
				return getParent() != null;
			case TagmlPackage.FOLDER_CONTENT__ARCHIVE:
				return getArchive() != null;
		}
		return super.eIsSet(featureID);
	}

} //FolderContentImpl
