/**
 */
package tagml;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Archive</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link tagml.Archive#getContents <em>Contents</em>}</li>
 * </ul>
 *
 * @see tagml.TagmlPackage#getArchive()
 * @model
 * @generated
 */
public interface Archive extends Element {
	/**
	 * Returns the value of the '<em><b>Contents</b></em>' containment reference list.
	 * The list contents are of type {@link tagml.FolderContent}.
	 * It is bidirectional and its opposite is '{@link tagml.FolderContent#getArchive <em>Archive</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Contents</em>' containment reference list.
	 * @see tagml.TagmlPackage#getArchive_Contents()
	 * @see tagml.FolderContent#getArchive
	 * @model opposite="archive" containment="true"
	 * @generated
	 */
	EList<FolderContent> getContents();

} // Archive
