/**
 */
package tagml;

import org.eclipse.emf.common.util.EList;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Document</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link tagml.Document#getRoot <em>Root</em>}</li>
 * </ul>
 *
 * @see tagml.TagmlPackage#getDocument()
 * @model
 * @generated
 */
public interface Document extends FolderContent {
	/**
	 * Returns the value of the '<em><b>Root</b></em>' containment reference list.
	 * The list contents are of type {@link tagml.TagContent}.
	 * It is bidirectional and its opposite is '{@link tagml.TagContent#getDocument <em>Document</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Root</em>' containment reference list.
	 * @see tagml.TagmlPackage#getDocument_Root()
	 * @see tagml.TagContent#getDocument
	 * @model opposite="document" containment="true" required="true"
	 * @generated
	 */
	EList<TagContent> getRoot();

} // Document
