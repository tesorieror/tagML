/**
 */
package tagml;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tag Content</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link tagml.TagContent#getParent <em>Parent</em>}</li>
 *   <li>{@link tagml.TagContent#getDocument <em>Document</em>}</li>
 * </ul>
 *
 * @see tagml.TagmlPackage#getTagContent()
 * @model abstract="true"
 * @generated
 */
public interface TagContent extends EObject {
	/**
	 * Returns the value of the '<em><b>Parent</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link tagml.Tag#getContent <em>Content</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parent</em>' container reference.
	 * @see #setParent(Tag)
	 * @see tagml.TagmlPackage#getTagContent_Parent()
	 * @see tagml.Tag#getContent
	 * @model opposite="content" transient="false"
	 * @generated
	 */
	Tag getParent();

	/**
	 * Sets the value of the '{@link tagml.TagContent#getParent <em>Parent</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Parent</em>' container reference.
	 * @see #getParent()
	 * @generated
	 */
	void setParent(Tag value);

	/**
	 * Returns the value of the '<em><b>Document</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link tagml.Document#getRoot <em>Root</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Document</em>' container reference.
	 * @see #setDocument(Document)
	 * @see tagml.TagmlPackage#getTagContent_Document()
	 * @see tagml.Document#getRoot
	 * @model opposite="root" transient="false"
	 * @generated
	 */
	Document getDocument();

	/**
	 * Sets the value of the '{@link tagml.TagContent#getDocument <em>Document</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Document</em>' container reference.
	 * @see #getDocument()
	 * @generated
	 */
	void setDocument(Document value);

} // TagContent
