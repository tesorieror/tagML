/**
 */
package tagml;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Folder Content</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link tagml.FolderContent#getParent <em>Parent</em>}</li>
 *   <li>{@link tagml.FolderContent#getArchive <em>Archive</em>}</li>
 * </ul>
 *
 * @see tagml.TagmlPackage#getFolderContent()
 * @model abstract="true"
 * @generated
 */
public interface FolderContent extends Element {
	/**
	 * Returns the value of the '<em><b>Parent</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link tagml.Folder#getContents <em>Contents</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Parent</em>' container reference.
	 * @see #setParent(Folder)
	 * @see tagml.TagmlPackage#getFolderContent_Parent()
	 * @see tagml.Folder#getContents
	 * @model opposite="contents" transient="false"
	 * @generated
	 */
	Folder getParent();

	/**
	 * Sets the value of the '{@link tagml.FolderContent#getParent <em>Parent</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Parent</em>' container reference.
	 * @see #getParent()
	 * @generated
	 */
	void setParent(Folder value);

	/**
	 * Returns the value of the '<em><b>Archive</b></em>' container reference.
	 * It is bidirectional and its opposite is '{@link tagml.Archive#getContents <em>Contents</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Archive</em>' container reference.
	 * @see #setArchive(Archive)
	 * @see tagml.TagmlPackage#getFolderContent_Archive()
	 * @see tagml.Archive#getContents
	 * @model opposite="contents" transient="false"
	 * @generated
	 */
	Archive getArchive();

	/**
	 * Sets the value of the '{@link tagml.FolderContent#getArchive <em>Archive</em>}' container reference.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Archive</em>' container reference.
	 * @see #getArchive()
	 * @generated
	 */
	void setArchive(Archive value);

} // FolderContent
