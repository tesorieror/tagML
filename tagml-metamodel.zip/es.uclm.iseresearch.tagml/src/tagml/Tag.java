/**
 */
package tagml;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Tag</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link tagml.Tag#getAttribute <em>Attribute</em>}</li>
 *   <li>{@link tagml.Tag#getContent <em>Content</em>}</li>
 * </ul>
 *
 * @see tagml.TagmlPackage#getTag()
 * @model
 * @generated
 */
public interface Tag extends Element, TagContent {
	/**
	 * Returns the value of the '<em><b>Attribute</b></em>' containment reference list.
	 * The list contents are of type {@link tagml.Attribute}.
	 * It is bidirectional and its opposite is '{@link tagml.Attribute#getTag <em>Tag</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Attribute</em>' containment reference list.
	 * @see tagml.TagmlPackage#getTag_Attribute()
	 * @see tagml.Attribute#getTag
	 * @model opposite="tag" containment="true"
	 * @generated
	 */
	EList<Attribute> getAttribute();

	/**
	 * Returns the value of the '<em><b>Content</b></em>' containment reference list.
	 * The list contents are of type {@link tagml.TagContent}.
	 * It is bidirectional and its opposite is '{@link tagml.TagContent#getParent <em>Parent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Content</em>' containment reference list.
	 * @see tagml.TagmlPackage#getTag_Content()
	 * @see tagml.TagContent#getParent
	 * @model opposite="parent" containment="true"
	 * @generated
	 */
	EList<TagContent> getContent();

} // Tag
