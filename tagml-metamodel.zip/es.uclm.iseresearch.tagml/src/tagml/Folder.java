/**
 */
package tagml;

import org.eclipse.emf.common.util.EList;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Folder</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * </p>
 * <ul>
 *   <li>{@link tagml.Folder#getContents <em>Contents</em>}</li>
 * </ul>
 *
 * @see tagml.TagmlPackage#getFolder()
 * @model
 * @generated
 */
public interface Folder extends FolderContent {
	/**
	 * Returns the value of the '<em><b>Contents</b></em>' containment reference list.
	 * The list contents are of type {@link tagml.FolderContent}.
	 * It is bidirectional and its opposite is '{@link tagml.FolderContent#getParent <em>Parent</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Contents</em>' containment reference list.
	 * @see tagml.TagmlPackage#getFolder_Contents()
	 * @see tagml.FolderContent#getParent
	 * @model opposite="parent" containment="true"
	 * @generated
	 */
	EList<FolderContent> getContents();

} // Folder
